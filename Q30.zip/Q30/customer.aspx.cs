﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data; 

namespace Q30
{
    public partial class customer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string cnstr = @"Data Source=.;Initial Catalog=XYZ;Integrated Security=True";
            SqlDataAdapter da = new SqlDataAdapter("Select * from product", cnstr);
            SqlDataAdapter da1 = new SqlDataAdapter("select * from Purchases", cnstr);
            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
            da.Fill(ds);
            da1.Fill(ds1);
            GridView1.DataSource = ds;
            GridView1.DataBind();
            GridView2.DataSource = ds1;
            GridView2.DataBind();
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            string cnstr = @"Data Source=.;Initial Catalog=XYZ;Integrated Security=True";
            string qry = "insert into Purchases values ('" + txtCN.Text + "'," + txtPID.Text +"," + txtQTY.Text + "," + txtAmt.Text + ")";
            SqlDataAdapter da = new SqlDataAdapter(qry, cnstr);
            DataSet ds2 = new DataSet();
            da.Fill(ds2);
            GridView2.DataSource = ds2;
            GridView2.DataBind();
        }
    }
}